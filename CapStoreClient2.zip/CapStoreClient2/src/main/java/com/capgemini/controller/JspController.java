package com.capgemini.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;



@Controller
public class JspController {

	@RequestMapping("/")
	ModelAndView loadIndex() {
		ModelAndView modelAndView = new ModelAndView("index");
		return modelAndView;
	}
	
	@RequestMapping("/customer-homepage")
	ModelAndView loadCustomerHomepage() {
		ModelAndView modelAndView = new ModelAndView("customer-homepage");
		return modelAndView;
	}
	
	@RequestMapping("/single")
	ModelAndView loadSingle() {
		ModelAndView modelAndView = new ModelAndView("single");
		return modelAndView;
	}
	
	@RequestMapping("/cart")
	ModelAndView loadCart() {
		ModelAndView modelAndView = new ModelAndView("cart");
		return modelAndView;
	}
	
	@RequestMapping("/wishlist")
	ModelAndView loadWishlist() {
		ModelAndView modelAndView = new ModelAndView("wishlist");
		return modelAndView;
	}
	
	@RequestMapping("/shipping-details")
	ModelAndView loadShippingDetails() {
		ModelAndView modelAndView = new ModelAndView("shipping-details");
		return modelAndView;
	}
	
	@RequestMapping("/coupons")
	ModelAndView loadCoupons() {
		ModelAndView modelAndView = new ModelAndView("coupons");
		return modelAndView;
	}
	
	@RequestMapping("/forget-pwd-email")
	ModelAndView loadForgetPassword_email() {
		ModelAndView modelAndView = new ModelAndView("forget-pwd-email");
		return modelAndView;
	}
	
	@RequestMapping("/forget-pwd-ques")
	ModelAndView loadForgetPassword_ques() {
		ModelAndView modelAndView = new ModelAndView("forget-pwd-ques");
		return modelAndView;
	}
	
	@RequestMapping("/forget-pwd")
	ModelAndView loadForgetPassword() {
		ModelAndView modelAndView = new ModelAndView("forget-pwd");
		return modelAndView;
	}
	
	@RequestMapping("/my-orders")
	ModelAndView loadMyOrders() {
		ModelAndView modelAndView = new ModelAndView("my-orders");
		return modelAndView;
	}
	
}
